#include "opgave1.h"
#include "opgave2.h"
#include "opgave3.h"
#include "opgave4.h"
#include "opgave5.h"
#include "opgave6.h"
#include "opgave7.h"

