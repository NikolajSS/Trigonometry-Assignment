#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <windows.h>
#define PI 3.14159265358979323846
#define val 180 / PI
#define val2 PI / 180

///Libraries get included and values get defined
