#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <windows.h>
#define PI 3.14159265358979323846
#define val 180 / PI //Helps us converting RADIANS into DEGREES
#define val2 PI / 180 //Helps us converting DEGREES into RADIANS

///Libraries get included and values get defined
